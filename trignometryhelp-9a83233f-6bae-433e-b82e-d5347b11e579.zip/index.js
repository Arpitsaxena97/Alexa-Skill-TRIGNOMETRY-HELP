
let speechOutput;
let reprompt;
let welcomeOutput = "Hello,Welcome to trignometry help, In this skill you can ask me about trignometry formulas like sine two A and many more, What you want to ask.";
let welcomeReprompt = "you can say something like : what is sin a cosb.";
// 2. Skill Code =======================================================================================================
"use strict";
const Alexa = require('alexa-sdk');
const APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).
speechOutput = '';
const handlers = {
	'LaunchRequest': function () {
		this.emit(':ask', welcomeOutput, welcomeReprompt);
	},
	'AMAZON.HelpIntent': function () {
		speechOutput = 'this skill is based on trignometry formulas if you are having any doubt in trignometry formulas then you can ask me about that.';
		
		this.emit(':ask', speechOutput);
	},
   'AMAZON.CancelIntent': function () {
		speechOutput = 'Thanks for using If you have any doubt please invoke me again.';
		this.emit(':tell', speechOutput);
	},
   'AMAZON.StopIntent': function () {
		speechOutput = 'Ok';
		this.emit(':tell', speechOutput);
   },
   'SessionEndedRequest': function () {
		speechOutput = '';
		//this.emit(':saveState', true);//uncomment to save attributes to db on session end
		this.emit(':tell', speechOutput);
   },
	'AMAZON.NavigateHomeIntent': function () {
		speechOutput = '';

		//any intent slot variables are listed here for convenience


		//Your custom intent handling goes here
		speechOutput = "you have been navigated to home ask if you are having any doubt you can ask me";
		this.emit(":ask", speechOutput, speechOutput);
    },
    'againIntent': function () {
		speechOutput = 'Ok, what do you want to ask, You can ask me.';
		this.emit(':ask', speechOutput);
    },
	'valueIntent': function () {
		speechOutput = '';

		//any intent slot variables are listed here for convenience
	let questionSlot = resolveCanonical(this.event.request.intent.slots.question);
		console.log('user requested question:' + questionSlot);

		//Your custom intent handling goes here
		var questions = {
			'sine ninty minus thita' : {
		    	'ans' : 'sine ninty minus thita =, plus cos thita.',
		    },
	        
		    'two tan inverse x' : {
		        'ans' : 'two tan inverse x = , sine inverse , (2X up on , 1 + x square). which is also = , cos inverse ( 1 minus x square up on , 1 + x square) , and in terms of tan it will be , tan inverse ( 2X up on,  1 minus x square).',
		    },
		    'cos inverse x minus cos inverse y' : {
		        'ans' : 'cos inverse x minus cos inverse y , = cos inverse , ( x y + square root of 1 minus x square , in to square root of , 1 minus y square). ',
		    },
		    'sine inverse x minus sine inverse y' : {
		        'ans' : 'sine inverse x minus sine inverse y = , sine inverse , ( x into square root of 1 minus y square , minus , y , in to , square root of , 1 minus x square).',
		    },
		    'cos inverse x plus cos inverse y' : {
		        'ans' : 'cos inverse x plus cos inverse y , = cos inverse , ( x y minus square root of 1 minus x square , in to square root of , 1 minus y square).',
		    },
		    'sine inverse x plus sine inverse y' : {
		        'ans' : 'sine inverse x plus sine inverse y = , sine inverse , ( x into square root of 1 minus y square , plus , y , in to , square root of , 1 minus x square).',
		    },
		    'tan inverse x minus tan inverse y' : {
		        'ans' : 'tan inverse x minus tan inverse y, = tan inverse , (x minus y , whole upon 1 + x y)',
		    },
		    'tan inverse x plus tan inverse y' : {
		        'ans' : 'if x into y is smaller than 1 , then tan inverse x plus tan inverse y , will be equals to tan inverse , (x + y , whole upon 1 minus x y). if x into y is greater than 1 , then tan inverse x plus tan inverse y , will be equals to pi + tan inverse , (x + y , whole upon 1 minus x y).  ',
		    },
		    'cosec inverse x plus sec inverse x' : {
		        'ans' : 'cosec inverse x plus sec inverse x ,= , pi divided by 2.',
		    },
		    'tan inverse x plus cot inverse x' : {
		        'ans' : 'tan inverse x plus cot inverse x,= , pi divided by 2.',
		    },
		    'sine inverse x plus cos inverse x' : {
		        'ans' : 'sine inverse x plus cos inverse x , = , pi divided by 2.',
		    },
		    'sine a cos b' : {
		        'ans' : 'sine A cos B ,= ,1 by 2 , (sine (A + B) , + sine (A minus B)).',
		    },
		    'cos a cos b' : {
		        'ans' : 'cso A cos B ,= ,1 by 2 , (cos (A + B) , + cos (A minus B))',
		    },
		    'sine a sine b' : {
		        'ans' : 'sine A sin B ,= ,1 by 2 , (cos (A minus B) , minus cos (A + B))',
		    },
		    'cos a minus cos b' : {
		        'ans' : 'cos A minus cos B = , 2 sin , A+B divided by 2 , into , sine , B minus A divided by 2.',
		    },
		    'cos a plus cos b' : {
		        'ans' : 'cos A + cos B , = , 2 cos , A+B divided by 2 , into , cos , A minus B divided by 2.',
		    },
		    'sine a minus sine b' : {
		        'ans' : 'sine A minus sine B ,= 2 cos , A+B divided by 2 , into , sine , A minus B divided by 2.',
		    },
		    'sine a plus sine b' : {
		        'ans' : 'sine A + sine B =, 2 sine , A+B divided by 2 , into , cos , A minus B divided by 2.',
		    },
		    'tan three a' : {
		        'ans' : 'tan 3A=, 3 tan A minus tan cube A, whole divided by , 1 minus , 3 tan square A.',
		    },
		    'cos three a' : {
		        'ans' : 'cos 3A =, 4 cos cube A , minus , 3 cos A.',
		    },
		    'sine three a' : {
		        'ans' : 'sine 3A =, 3 sine A , minus , 4 sine cube A.',
		    },
		    'tan two a' : {
		        'ans' : 'tan 2A =, 2 tan A, whole divided by , 1 + tan square A',
		    },
		    'cos two a' : {
		        'ans' : 'cos 2A =, cos square A , minus , sin square A , which is also equals to , 1 minus, 2 sine square A . and it is also equals to , 2 cos square A , minus , 1.',
		    },
		    'sine two a' : {
		        'ans' : 'sine 2A=, 2 sine A , into cos A. which is also equals to , 2 tan A , whole divded by , 1 + tan square A.',
		    },
		    'tan a minus b' : {
		        'ans' : 'tan (A minus B) = , (tan A minus tan B), whole divided by , 1 + tan A , into tan B.',
		    },
		    'tan a plus b' : {
		        'ans' : 'tan (A + B) = , (tan A + tan B), whole divided by , 1 minus tan A , into tan B.',
		    },
		    'cos a minus b' : {
		        'ans' : 'cos A minus B =, cos A , into cos B , + sine A , into sine B.',
		    },
		    'cos a plus b' : {
		        'ans' : 'cos A + B =, cos A , into cos B , minus sine A , into sine B.',
		    },
		    'sine a minus b' : {
		        'ans' : 'sine A minus B =, sine A , into cos B , minus cos A , into sine B.',
		    },
		    'sine a plus b' : {
		        'ans' : 'sine A + B =, sine A , into cos B , + cos A , into sine B.',
		    },
		    'cos ninty minus thita' :{
		    	'ans' :'cos ninty minus thita =, plus sine thita.',
		    },
		    'tan ninty minus thita' :{
		    	'ans' : 'tan ninty minus thita =, plus cot thita.',
		    },
		    'cosec ninty minus thita' :{
		    	'ans' :'cosec ninty minus thita =, plus sec thita.',
		    },
		    'sec ninty minus thita' :{
		    	'ans' :'sec ninty minus thita =, plus cosec thita.',
		    },
		    'cot ninty minus thita' :{
		    	'ans' :'cot ninty minus thita =,plus tan thita.',
		    },
		    'sine ninty plus thita' :{
		    	'ans' :'sine ninty plus thita =, plus cos thita.',
		    },
		    'cos ninty plus thita' :{
		    	'ans' :'cos ninty plus thita =, minus sine thita.',
		    },
		    'tan ninty plus thita' :{
		    	'ans' :'tan ninty plus thita =, minus cos thita.',
		    },
		    'cosec ninty plus thita' :{
		    	'ans' :'cosec ninty plus thita =, plus sec thita.',
		    },
		    'sec ninty plus thita' :{
		    	'ans' :'sec ninty plus thita =, minus cosec thita.',
		    },
		    'cot ninty plus thita' :{
		    	'ans' :'cot ninty plus thita =, minus tan thita.',
		    },

		};
		
	
		    
		    
		    var question = questionSlot.toLowerCase();
		    
		    if(questionSlot && questions[question])
		    {
		       // var audio = '';
		        var reply = 'ans'; //default pitch
		        
		        
		       var audioSrc = questions[question][reply];
		        
		        speechOutput = audioSrc + '. do you want to ask me some more formulas.';
		      
		    } 
		    
		    else 
		    {
		        speechOutput = 'Sorry, I do not know that Please try to say other words Thankyou';
		      
		    }
		    
		    this.emit(":ask", speechOutput);
    },
	'Unhandled': function () {
        speechOutput = "The skill didn't quite understand what you wanted.  Do you want to try something else?";
        this.emit(':ask', speechOutput, speechOutput);
    }
};

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.appId = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    //alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
	//alexa.dynamoDBTableName = 'DYNAMODB_TABLE_NAME'; //uncomment this line to save attributes to DB
    alexa.execute();
};

//    END of Intent Handlers {} ========================================================================================
// 3. Helper Function  =================================================================================================

function resolveCanonical(slot){
	//this function looks at the entity resolution part of request and returns the slot value if a synonyms is provided
	let canonical;
    try{
		canonical = slot.resolutions.resolutionsPerAuthority[0].values[0].value.name;
	}catch(err){
	    console.log(err.message);
	    canonical = slot.value;
	};
	return canonical;
};

function delegateSlotCollection(){
  console.log("in delegateSlotCollection");
  console.log("current dialogState: "+this.event.request.dialogState);
    if (this.event.request.dialogState === "STARTED") {
      console.log("in Beginning");
	  let updatedIntent= null;
	  // updatedIntent=this.event.request.intent;
      //optionally pre-fill slots: update the intent object with slot values for which
      //you have defaults, then return Dialog.Delegate with this updated intent
      // in the updatedIntent property
      //this.emit(":delegate", updatedIntent); //uncomment this is using ASK SDK 1.0.9 or newer
	  
	  //this code is necessary if using ASK SDK versions prior to 1.0.9 
	  if(this.isOverridden()) {
			return;
		}
		this.handler.response = buildSpeechletResponse({
			sessionAttributes: this.attributes,
			directives: getDialogDirectives('Dialog.Delegate', updatedIntent, null),
			shouldEndSession: false
		});
		this.emit(':responseReady', updatedIntent);
		
    } else if (this.event.request.dialogState !== "COMPLETED") {
      console.log("in not completed");
      // return a Dialog.Delegate directive with no updatedIntent property.
      //this.emit(":delegate"); //uncomment this is using ASK SDK 1.0.9 or newer
	  
	  //this code necessary is using ASK SDK versions prior to 1.0.9
		if(this.isOverridden()) {
			return;
		}
		this.handler.response = buildSpeechletResponse({
			sessionAttributes: this.attributes,
			directives: getDialogDirectives('Dialog.Delegate', null, null),
			shouldEndSession: false
		});
		this.emit(':responseReady');
		
    } else {
      console.log("in completed");
      console.log("returning: "+ JSON.stringify(this.event.request.intent));
      // Dialog is now complete and all required slots should be filled,
      // so call your normal intent handler.
      return this.event.request.intent;
    }
}


function randomPhrase(array) {
    // the argument is an array [] of words or phrases
    let i = 0;
    i = Math.floor(Math.random() * array.length);
    return(array[i]);
}
function isSlotValid(request, slotName){
        let slot = request.intent.slots[slotName];
        //console.log("request = "+JSON.stringify(request)); //uncomment if you want to see the request
        let slotValue;

        //if we have a slot, get the text and store it into speechOutput
        if (slot && slot.value) {
            //we have a value in the slot
            slotValue = slot.value.toLowerCase();
            return slotValue;
        } else {
            //we didn't get a value in the slot.
            return false;
        }
}

//These functions are here to allow dialog directives to work with SDK versions prior to 1.0.9
//will be removed once Lambda templates are updated with the latest SDK

function createSpeechObject(optionsParam) {
    if (optionsParam && optionsParam.type === 'SSML') {
        return {
            type: optionsParam.type,
            ssml: optionsParam['speech']
        };
    } else {
        return {
            type: optionsParam.type || 'PlainText',
            text: optionsParam['speech'] || optionsParam
        };
    }
}

function buildSpeechletResponse(options) {
    let alexaResponse = {
        shouldEndSession: options.shouldEndSession
    };

    if (options.output) {
        alexaResponse.outputSpeech = createSpeechObject(options.output);
    }

    if (options.reprompt) {
        alexaResponse.reprompt = {
            outputSpeech: createSpeechObject(options.reprompt)
        };
    }

    if (options.directives) {
        alexaResponse.directives = options.directives;
    }

    if (options.cardTitle && options.cardContent) {
        alexaResponse.card = {
            type: 'Simple',
            title: options.cardTitle,
            content: options.cardContent
        };

        if(options.cardImage && (options.cardImage.smallImageUrl || options.cardImage.largeImageUrl)) {
            alexaResponse.card.type = 'Standard';
            alexaResponse.card['image'] = {};

            delete alexaResponse.card.content;
            alexaResponse.card.text = options.cardContent;

            if(options.cardImage.smallImageUrl) {
                alexaResponse.card.image['smallImageUrl'] = options.cardImage.smallImageUrl;
            }

            if(options.cardImage.largeImageUrl) {
                alexaResponse.card.image['largeImageUrl'] = options.cardImage.largeImageUrl;
            }
        }
    } else if (options.cardType === 'LinkAccount') {
        alexaResponse.card = {
            type: 'LinkAccount'
        };
    } else if (options.cardType === 'AskForPermissionsConsent') {
        alexaResponse.card = {
            type: 'AskForPermissionsConsent',
            permissions: options.permissions
        };
    }

    let returnResult = {
        version: '1.0',
        response: alexaResponse
    };

    if (options.sessionAttributes) {
        returnResult.sessionAttributes = options.sessionAttributes;
    }
    return returnResult;
}

function getDialogDirectives(dialogType, updatedIntent, slotName) {
    let directive = {
        type: dialogType
    };

    if (dialogType === 'Dialog.ElicitSlot') {
        directive.slotToElicit = slotName;
    } else if (dialogType === 'Dialog.ConfirmSlot') {
        directive.slotToConfirm = slotName;
    }

    if (updatedIntent) {
        directive.updatedIntent = updatedIntent;
    }
    return [directive];
}